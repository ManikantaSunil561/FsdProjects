package Ap1;
public class PillarsOfOOPS{
    public static void main(String[] args) 
    { 
        Dog scott = new Dog("Scott","papillon", 5, "black"); 
        System.out.println(scott.toString()); 
    } 
}

