package Ap1;
public class AccessSpecifier3 extends ProtectedAccessSpecifier{
	public static void main(String[] args) {
		AccessSpecifier3 obj = new AccessSpecifier3 ();   
	       obj.display();  
	}

}