package Ap1;
public class AccessSpecifier4 {
	public static void main(String[] args) {
		
		PublicAccessSpecifier obj = new PublicAccessSpecifier(); 
        obj.display();  
		
	}
}