package Ap1;
public class ProtectedAccessSpecifier{
	protected void display() 
    { 
        System.out.println("This is protected access specifier"); 
    } 
}