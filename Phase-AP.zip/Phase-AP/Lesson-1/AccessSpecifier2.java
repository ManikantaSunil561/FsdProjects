package Ap1;
public class AccessSpecifier2 {

	public static void main(String[] args) {
		//private
		System.out.println("Private Access Specifier");
		PrivateAccessSpecifier obj = new PrivateAccessSpecifier();  
        //obj.display();

	}
}